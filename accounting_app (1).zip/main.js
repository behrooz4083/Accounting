// نمونه اولیه کد React برای احراز هویت با Supabase
console.log('Accounting App Loaded');